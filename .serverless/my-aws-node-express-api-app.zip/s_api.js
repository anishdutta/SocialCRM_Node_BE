
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'anishdutta',
  applicationName: 'my-aws-node-express-api-app',
  appUid: '1jnGlYsqyvdwLh6KXw',
  orgUid: 'fcc45e08-457a-4819-bd98-b914f5c0d231',
  deploymentUid: 'e2cca8b1-2957-4e43-b650-6beee80460be',
  serviceName: 'my-aws-node-express-api-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-aws-node-express-api-app-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}